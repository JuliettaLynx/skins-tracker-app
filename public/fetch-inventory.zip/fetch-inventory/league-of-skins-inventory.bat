@echo off
powershell -ExecutionPolicy Bypass -File "fetch-inventory.ps1"
pause