# ============================================================
# League of Legends Exporter: skins + shards + store (filtered)
# Store filter: CHAMPION_SKIN + subInventoryType=null + cost>0
# ============================================================
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding           = [System.Text.Encoding]::UTF8

Write-Host "Getting your League of Legends data..." -ForegroundColor Cyan

# ------------------------------------------------------------
# 1. Find lockfile
# ------------------------------------------------------------
$possiblePaths = @(
    "C:\Riot Games\League of Legends\lockfile",
    "D:\Riot Games\League of Legends\lockfile",
    "E:\Riot Games\League of Legends\lockfile",
    "F:\Riot Games\League of Legends\lockfile",
    "$env:USERPROFILE\AppData\Local\Riot Games\League of Legends\Config\lockfile",
    "$env:USERPROFILE\AppData\Local\Riot Games\Riot Client\Config\lockfile"
)

$lockfileFound = $false
foreach ($path in $possiblePaths) {
    if (Test-Path $path) {
        $lcuPath = $path
        $lockfileFound = $true
        Write-Host "Found lockfile: $path" -ForegroundColor Green
        break
    }
}

if (-not $lockfileFound) {
    Write-Host "ERROR: League of Legends is not running!" -ForegroundColor Red
    Write-Host "Please start League of Legends and try again." -ForegroundColor Yellow
    pause
    exit
}

$content  = Get-Content $lcuPath
$parts    = $content -split ":"
$port     = $parts[2]
$password = $parts[3]
Write-Host "Port: $port" -ForegroundColor Cyan

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

$auth    = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("riot:$password"))
$baseUrl = "https://127.0.0.1:$port"

# ------------------------------------------------------------
# 2. LCU GET helper
# ------------------------------------------------------------
function Invoke-LcuGet {
    param([string]$Url, [int]$TimeoutSec = 30000)
    $req = [System.Net.WebRequest]::Create($Url)
    $req.Method      = "GET"
    $req.Headers.Add("Authorization", "Basic $auth")
    $req.ContentType = "application/json"
    $req.Accept      = "application/json"
    $req.Timeout     = $TimeoutSec

    $resp   = $req.GetResponse()
    $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
    $text   = $reader.ReadToEnd()
    $reader.Close()
    $resp.Close()
    return $text
}

# ============================================================
# 3. Purchased skins
# ============================================================
Write-Host "`n[1/3] Getting purchased skins..." -ForegroundColor Yellow
$skinsArray = @()
try {
    $rawSkins = Invoke-LcuGet -Url "$baseUrl/lol-inventory/v2/inventory/CHAMPION_SKIN"
    $parsed = $rawSkins | ConvertFrom-Json
    if ($parsed -is [System.Array]) {
        $skinsArray = @($parsed)
    } elseif ($parsed -and ($parsed.PSObject.Properties.Name -contains 'value')) {
        $skinsArray = @($parsed.value)
    } else {
        $skinsArray = @($parsed)
    }
    Write-Host "    Found $($skinsArray.Count) purchased skins" -ForegroundColor Green
} catch {
    Write-Host "    Error: $_" -ForegroundColor Red
}

# ============================================================
# 4. Skin shards
# ============================================================
Write-Host "`n[2/3] Getting loot (shards)..." -ForegroundColor Yellow
$shards = @()
try {
    $rawLoot  = Invoke-LcuGet -Url "$baseUrl/lol-loot/v1/player-loot-map"
    $lootData = $rawLoot | ConvertFrom-Json
    $shardList = @()
    foreach ($p in $lootData.PSObject.Properties) {
        $item = $p.Value
        if ($item -and $item.lootId -like 'CHAMPION_SKIN_RENTAL_*') {
            $shardList += $item
        }
    }
    $shards = @($shardList)
    Write-Host "    Found $($shards.Count) skin shards" -ForegroundColor Green
} catch {
    Write-Host "    Error: $_" -ForegroundColor Red
}

# ============================================================
# 5. Store catalog (strict filter)
#    inventoryType    = CHAMPION_SKIN
#    subInventoryType = null (excludes RECOLOR and others)
#    prices has entry with cost > 0
# ============================================================
Write-Host "`n[3/3] Getting store catalog..." -ForegroundColor Yellow
$storeItems    = @()
$storeFiltered = @()
try {
    $storeCatalogRaw = Invoke-LcuGet -Url "$baseUrl/lol-store/v1/catalog" -TimeoutSec 30000
    $storeObj = $storeCatalogRaw | ConvertFrom-Json
    if ($storeObj -is [System.Array]) {
        $storeItems = @($storeObj)
    } elseif ($storeObj.PSObject.Properties.Name -contains 'catalog') {
        $storeItems = @($storeObj.catalog)
    } elseif ($storeObj.PSObject.Properties.Name -contains 'items') {
        $storeItems = @($storeObj.items)
    } else {
        $storeItems = @($storeObj)
    }

    $storeFiltered = @($storeItems | Where-Object {
        # 1. inventoryType must be exactly CHAMPION_SKIN
        if ($_.inventoryType -ne 'CHAMPION_SKIN') { return $false }

        # 2. subInventoryType must be exactly null (this excludes RECOLOR and any other value)
        if ($null -ne $_.subInventoryType) { return $false }

        # 3. prices must contain an entry with cost > 0
        if (-not $_.prices) { return $false }
        $hasPositiveCost = $false
        foreach ($pr in @($_.prices)) {
            if ($null -ne $pr.cost -and [double]$pr.cost -gt 0) {
                $hasPositiveCost = $true
                break
            }
        }
        return $hasPositiveCost
    })

    Write-Host "    Loaded $($storeItems.Count) items from catalog" -ForegroundColor Green
    Write-Host "    After filter (CHAMPION_SKIN + subInventoryType=null + cost>0): $($storeFiltered.Count)" -ForegroundColor Green

    # Diagnostic: subInventoryType distribution in raw catalog for CHAMPION_SKIN only
    $champSkins = @($storeItems | Where-Object { $_.inventoryType -eq 'CHAMPION_SKIN' })
    $subStats = @{}
    foreach ($it in $champSkins) {
        $k = if ($null -eq $it.subInventoryType) { '<null>' } else { [string]$it.subInventoryType }
        if (-not $subStats.ContainsKey($k)) { $subStats[$k] = 0 }
        $subStats[$k]++
    }
    Write-Host "    subInventoryType distribution among CHAMPION_SKIN items:" -ForegroundColor DarkGray
    foreach ($kv in ($subStats.GetEnumerator() | Sort-Object Name)) {
        Write-Host ("      {0,-14} : {1}" -f $kv.Key, $kv.Value) -ForegroundColor DarkGray
    }
} catch {
    Write-Host "    Error: $_" -ForegroundColor Red
}

# ============================================================
# 6. Save with 3 categories
# ============================================================
Write-Host "`nSaving..." -ForegroundColor Yellow

$combined = [ordered]@{
    skins  = @($skinsArray)
    shards = @($shards)
    store  = @($storeFiltered)
}

$json = ConvertTo-Json -InputObject $combined -Depth 40
# Convert escaped \uXXXX back to readable Cyrillic (PS 5.1 escapes non-ASCII)
$json = [regex]::Replace($json, '\\u([0-9a-fA-F]{4})', {
    param($m) [char][Convert]::ToInt32($m.Groups[1].Value, 16)
})

$outPath = Join-Path $PWD "inventory.json"
[System.IO.File]::WriteAllText($outPath, $json, (New-Object System.Text.UTF8Encoding($false)))

Write-Host "`nSaved: $outPath" -ForegroundColor Yellow
Write-Host ("Size: {0:N1} KB" -f ((Get-Item $outPath).Length / 1KB)) -ForegroundColor Gray

# ============================================================
# 7. VERIFY: read back and confirm 3 categories + filter inside store
# ============================================================
Write-Host "`n=== VERIFY inventory.json ===" -ForegroundColor Magenta

$verifyRaw = [System.IO.File]::ReadAllText($outPath, [System.Text.Encoding]::UTF8)
$verifyObj = $verifyRaw | ConvertFrom-Json

$expected = @('skins', 'shards', 'store')
$actual   = @($verifyObj.PSObject.Properties.Name)
$missing  = @($expected | Where-Object { $actual -notcontains $_ })
$extra    = @($actual   | Where-Object { $expected -notcontains $_ })

Write-Host "  Expected categories: $($expected -join ', ')" -ForegroundColor Cyan
Write-Host "  Actual categories  : $($actual   -join ', ')" -ForegroundColor Cyan

foreach ($name in $expected) {
    if ($actual -notcontains $name) {
        Write-Host "  [MISSING] $name" -ForegroundColor Red
        continue
    }
    $cnt = @($verifyObj.$name).Count
    $tag = if ($cnt -eq 0) { "EMPTY" } else { "OK" }
    $color = if ($cnt -eq 0) { "Yellow" } else { "Green" }
    Write-Host ("  [{0,-7}] {1,-8} : {2} items" -f $tag, $name, $cnt) -ForegroundColor $color
}
foreach ($name in $extra) {
    Write-Host "  [EXTRA  ] $name" -ForegroundColor Yellow
}

# Sanity check inside saved store
$badType   = @($verifyObj.store | Where-Object { $_.inventoryType -ne 'CHAMPION_SKIN' })
$badSub    = @($verifyObj.store | Where-Object { $null -ne $_.subInventoryType })
$badCost   = @($verifyObj.store | Where-Object {
    if (-not $_.prices) { return $true }
    $ok = $false
    foreach ($pr in @($_.prices)) { if ($null -ne $pr.cost -and [double]$pr.cost -gt 0) { $ok = $true; break } }
    return (-not $ok)
})

Write-Host "`n  Store contents check:" -ForegroundColor Cyan
Write-Host ("    inventoryType != CHAMPION_SKIN : {0}" -f $badType.Count) -ForegroundColor $(if ($badType.Count -eq 0) { "Green" } else { "Red" })
Write-Host ("    subInventoryType != null       : {0}" -f $badSub.Count)  -ForegroundColor $(if ($badSub.Count  -eq 0) { "Green" } else { "Red" })
Write-Host ("    no price with cost > 0         : {0}" -f $badCost.Count) -ForegroundColor $(if ($badCost.Count -eq 0) { "Green" } else { "Red" })

if ($missing.Count -eq 0 -and $extra.Count -eq 0 -and
    $badType.Count -eq 0 -and $badSub.Count -eq 0 -and $badCost.Count -eq 0) {
    Write-Host "`n  RESULT: 3 categories present, store filter correct. OK." -ForegroundColor Green
} else {
    Write-Host "`n  RESULT: mismatch detected." -ForegroundColor Red
}

Write-Host "`nDone." -ForegroundColor Green
pause